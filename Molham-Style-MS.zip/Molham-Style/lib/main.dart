import 'package:flutter/material.dart';

void main() => runApp(const MolhamStyleApp());

class Product {
  final String name;
  final String category;
  final int price;
  final String image;
  const Product(this.name, this.category, this.price, this.image);
}

const products = [
  Product('فستان ساتان بيج', 'ملابس', 35, 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=900'),
  Product('سنيكرز أبيض', 'أحذية', 42, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900'),
  Product('حقيبة كتف فاخرة', 'إكسسوارات', 28, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900'),
  Product('طقم كاجوال أنيق', 'ملابس', 49, 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900'),
  Product('جاكيت جينز', 'ملابس', 39, 'https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=900'),
  Product('حذاء كلاسيك', 'أحذية', 45, 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=900'),
];

class MolhamStyleApp extends StatelessWidget {
  const MolhamStyleApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFB08D57);
    const cream = Color(0xFFF7F1E8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Molham Style',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: gold),
        scaffoldBackgroundColor: cream,
        fontFamily: 'sans',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final cart = <Product>[];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _category('ملابس'),
      _category('أحذية'),
      _category('إكسسوارات'),
      _account(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Molham Style', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: const Color(0xFFF7F1E8),
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.checkroom_outlined), label: 'ملابس'),
            NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'أحذية'),
            NavigationDestination(icon: Icon(Icons.watch_outlined), label: 'إكسسوارات'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
        floatingActionButton: cart.isEmpty ? null : FloatingActionButton.extended(
          onPressed: () => _checkout(),
          icon: const Icon(Icons.shopping_cart),
          label: Text('السلة ${cart.length}'),
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 90),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: const Color(0xFF171714),
          borderRadius: BorderRadius.circular(26),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('MOLHAM STYLE',
              style: TextStyle(color: Color(0xFFD8B978), fontSize: 14, letterSpacing: 2, fontWeight: FontWeight.w700)),
            SizedBox(height: 12),
            Text('أناقتك تبدأ من هنا',
              style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('اكتشف تشكيلتنا المختارة من الملابس والأحذية والإكسسوارات.',
              style: TextStyle(color: Colors.white70, height: 1.5)),
          ],
        ),
      ),
      const SizedBox(height: 18),
      TextField(
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(
          hintText: 'ابحث عن منتج...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 22),
      const Text('الأقسام', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Row(
        children: [
          _categoryChip('ملابس', Icons.checkroom_outlined, 1),
          const SizedBox(width: 8),
          _categoryChip('أحذية', Icons.shopping_bag_outlined, 2),
          const SizedBox(width: 8),
          _categoryChip('إكسسوارات', Icons.watch_outlined, 3),
        ],
      ),
      const SizedBox(height: 24),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: const [
          Text('وصل حديثاً', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          Text('عرض الكل', style: TextStyle(color: Color(0xFF9A7945), fontWeight: FontWeight.w600)),
        ],
      ),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .66,
        ),
        itemBuilder: (_, i) => _card(products[i]),
      ),
    ],
  );

  Widget _categoryChip(String title, IconData icon, int page) => Expanded(
    child: InkWell(
      onTap: () => setState(() => index = page),
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Icon(icon, size: 25),
            const SizedBox(height: 7),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
          ],
        ),
      ),
    ),
  );

  Widget _category(String cat) {
    final list = products.where((p) => p.category == cat).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(cat, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        ...list.map(_wideCard),
      ],
    );
  }

  Widget _card(Product p) => InkWell(
    onTap: () => _details(p),
    borderRadius: BorderRadius.circular(18),
    child: Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(child: Image.network(p.image, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported, size: 50))),
          Padding(padding: const EdgeInsets.all(10), child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
          Padding(padding: const EdgeInsets.fromLTRB(10,0,10,10),
            child: Text('${p.price} \$', style: const TextStyle(fontWeight: FontWeight.bold))),
        ],
      ),
    ),
  );

  Widget _wideCard(Product p) => Card(
    child: ListTile(
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(p.image, width: 65, height: 65, fit: BoxFit.cover)),
      title: Text(p.name),
      subtitle: Text('${p.price} \$'),
      trailing: IconButton(icon: const Icon(Icons.add_shopping_cart), onPressed: () => setState(() => cart.add(p))),
      onTap: () => _details(p),
    ),
  );

  void _details(Product p) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.network(p.image, height: 240, width: double.infinity, fit: BoxFit.cover)),
            const SizedBox(height: 14),
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text('${p.price} \$', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () { setState(() => cart.add(p)); Navigator.pop(context); },
              icon: const Icon(Icons.shopping_cart),
              label: const Text('أضف إلى السلة'),
            ),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }

  void _checkout() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إتمام الطلب'),
        content: Text('عدد المنتجات: ${cart.length}\nالدفع عند الاستلام متاح في هذه النسخة التجريبية.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            setState(() => cart.clear());
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال الطلب بنجاح')));
          }, child: const Text('تأكيد الطلب')),
        ],
      ),
    );
  }

  Widget _account() => const Center(
    child: Padding(
      padding: EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(radius: 40, child: Icon(Icons.person, size: 45)),
        SizedBox(height: 15),
        Text('حسابي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('سجّل الدخول لاحقاً لمتابعة طلباتك وعناوينك المفضلة.'),
      ]),
    ),
  );
}
