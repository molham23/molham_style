# Molham Style
تطبيق متجر أزياء عربي تجريبي (Flutter) للملابس والأحذية والإكسسوارات.

## بناء APK
المشروع يحتوي على GitHub Actions لبناء نسخة Android Release تلقائياً.
