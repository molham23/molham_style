import 'package:flutter/material.dart';

void main() => runApp(const MolhamStyleApp());

class Product {
  final String name;
  final String category;
  final int price;
  final String image;
  const Product(this.name, this.category, this.price, this.image);
}

const products = [
  Product('فستان بيج أنيق', 'ملابس', 35, 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800'),
  Product('حذاء أبيض عصري', 'أحذية', 42, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800'),
  Product('حقيبة جلد فاخرة', 'إكسسوارات', 28, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800'),
  Product('طقم كاجوال', 'ملابس', 49, 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800'),
];

class MolhamStyleApp extends StatelessWidget {
  const MolhamStyleApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFB08D57);
    const cream = Color(0xFFF7F1E8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Molham Style',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: gold),
        scaffoldBackgroundColor: cream,
        fontFamily: 'sans',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final cart = <Product>[];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _category('ملابس'),
      _category('أحذية'),
      _category('إكسسوارات'),
      _account(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Molham Style', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: const Color(0xFFF7F1E8),
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.checkroom_outlined), label: 'ملابس'),
            NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'أحذية'),
            NavigationDestination(icon: Icon(Icons.watch_outlined), label: 'إكسسوارات'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
        floatingActionButton: cart.isEmpty ? null : FloatingActionButton.extended(
          onPressed: () => _checkout(),
          icon: const Icon(Icons.shopping_cart),
          label: Text('السلة ${cart.length}'),
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: const Color(0xFF1B1B18),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('أناقتك تبدأ من هنا', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Molham Style', style: TextStyle(color: Color(0xFFD8B978), fontSize: 18)),
            SizedBox(height: 8),
            Text('ملابس • أحذية • إكسسوارات', style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
      const SizedBox(height: 20),
      const Text('وصل حديثاً', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .68,
        ),
        itemBuilder: (_, i) => _card(products[i]),
      ),
    ],
  );

  Widget _category(String cat) {
    final list = products.where((p) => p.category == cat).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(cat, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        ...list.map(_wideCard),
      ],
    );
  }

  Widget _card(Product p) => InkWell(
    onTap: () => _details(p),
    borderRadius: BorderRadius.circular(18),
    child: Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(child: Image.network(p.image, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported, size: 50))),
          Padding(padding: const EdgeInsets.all(10), child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
          Padding(padding: const EdgeInsets.fromLTRB(10,0,10,10),
            child: Text('${p.price} \$', style: const TextStyle(fontWeight: FontWeight.bold))),
        ],
      ),
    ),
  );

  Widget _wideCard(Product p) => Card(
    child: ListTile(
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(p.image, width: 65, height: 65, fit: BoxFit.cover)),
      title: Text(p.name),
      subtitle: Text('${p.price} \$'),
      trailing: IconButton(icon: const Icon(Icons.add_shopping_cart), onPressed: () => setState(() => cart.add(p))),
      onTap: () => _details(p),
    ),
  );

  void _details(Product p) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.network(p.image, height: 240, width: double.infinity, fit: BoxFit.cover)),
            const SizedBox(height: 14),
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text('${p.price} \$', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () { setState(() => cart.add(p)); Navigator.pop(context); },
              icon: const Icon(Icons.shopping_cart),
              label: const Text('أضف إلى السلة'),
            ),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }

  void _checkout() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إتمام الطلب'),
        content: Text('عدد المنتجات: ${cart.length}\nالدفع عند الاستلام متاح في هذه النسخة التجريبية.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            setState(() => cart.clear());
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال الطلب بنجاح')));
          }, child: const Text('تأكيد الطلب')),
        ],
      ),
    );
  }

  Widget _account() => const Center(
    child: Padding(
      padding: EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(radius: 40, child: Icon(Icons.person, size: 45)),
        SizedBox(height: 15),
        Text('حسابي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('سجّل الدخول لاحقاً لمتابعة طلباتك وعناوينك المفضلة.'),
      ]),
    ),
  );
}
